from preprocessing.base_preprocessor import BasePreprocessor
from preprocessing.pass_preproccessor import PASSpreprocessor
from preprocessing.dense_cols_preprocessor import DenseColsPreprocessor
from preprocessing.imputer_preprocessor import ImputerPreprocessor
from preprocessing.standardizer_preprocessor import StandardizerPreprocessor


class FinancialPreprocessor(BasePreprocessor):

    def __init__(self, **kwargs):

        self.dense_cols_preprocessor = (
            DenseColsPreprocessor(**kwargs)
            if kwargs.get("num_dense_cols", None)
            else PASSpreprocessor()
        )
        self.imputer_prepocessor = (
            ImputerPreprocessor(**kwargs)
            if kwargs.get("imputer", None)
            else PASSpreprocessor()
        )
        self.standardizer_preprocessor = (
            StandardizerPreprocessor(source='financial')
            if kwargs.get("standardize", None)
            else PASSpreprocessor()
        )
        self.preprocessors = [
            self.dense_cols_preprocessor,
            self.standardizer_preprocessor,
            self.imputer_prepocessor            
        ]

    def fit_transform(self, X):

        for p in self.preprocessors:
            X = p.fit_transform(X)
        return X

    def transform(self, X):
        for p in self.preprocessors:
            X = p.transform(X)
        return X

    def save(self):
        for p in self.preprocessors:
            p.save()

    def load(self):
        for p in self.preprocessors:
            p.load()
